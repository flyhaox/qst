package de.ostfalia.qst.gasstation;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import de.ostfalia.qst.gasstation.comp.Article;
import de.ostfalia.qst.gasstation.comp.Bill;
import de.ostfalia.qst.gasstation.comp.FillingStation;
import de.ostfalia.qst.gasstation.comp.Sellable;

public class Main {

    public static void main(String[] args) {

    	/* Creating the Stations and adding to the manager */
		FillingStationManager manager = new FillingStationManager();
		FillingStation esso = new FillingStation("Esso");
		FillingStation shell = new FillingStation("Aral");
		FillingStation aral = new FillingStation("Shell");
		manager.add(esso);
		manager.add(shell);
		manager.add(aral);

		/* Adding another article to a station */
		Article snickers = new Article("Snickers", 1.49);
		LocalDateTime discountStart = LocalDateTime.of(LocalDate.of(2018, 3, 20), //java:S117 Rename this local variable to match the regular expression '^[a-z][a-zA-Z0-9]*$'
										   LocalTime.of(12, 0, 0));

		LocalDateTime discountEnd = LocalDateTime.of(LocalDate.of(2018, 5, 10), //java:S117 Rename this local variable to match the regular expression '^[a-z][a-zA-Z0-9]*$'
										   LocalTime.of(12, 0, 0));

		/* Setting a discount to the new article */
		snickers.setDiscount(1.19, discountStart, discountEnd);
		esso.addGood(snickers);

		/* Creating a Bill **/
		Bill b = esso.newBill(true);
		Sellable s = esso.getGood("Diesel");
		Sellable s2 = esso.getGood("Snickers");
		b.add(s, 35.31);
		b.add(s2, 4);
		esso.saveBill(b);

		/* Bill Output **/
		System.out.println(b.toString()); //NOSONAR rule:S106 IGNORE Replace this use of System.out or System.err by a logger.

		/* One more bill */
		Sellable bun = shell.getGood("Belegtes Broetchen");
		Sellable coffee = shell.getGood("Kaffee");
		Sellable e10 = shell.getGood("E10");

		Bill b2 = shell.newBill(false);
		b2.add(bun, 3);
		b2.add(coffee, 1);
		b2.add(e10, 13.37);
		esso.saveBill(b2);
		System.out.println(b2.toString()); //NOSONAR rule:S106 IGNORE Replace this use of System.out or System.err by a logger.

		/* Manager revenue */
		LocalDateTime revenueStart = LocalDateTime.of(LocalDate.of(2018, 3, 20), 
				LocalTime.of(12, 0, 0)); //java:S117 Rename this local variable to match the regular expression '^[a-z][a-zA-Z0-9]*$'

		LocalDateTime revenueEnd = LocalDateTime.of(LocalDate.of(2018, 5, 10),
				LocalTime.of(12, 0, 0)); //java:S117 Rename this local variable to match the regular expression '^[a-z][a-zA-Z0-9]*$'
		double revenue = manager.getRevenue(esso, revenueStart, revenueEnd);
		System.out.println(revenue); //NOSONAR rule:S106 IGNORE Replace this use of System.out or System.err by a logger.
	}
}
