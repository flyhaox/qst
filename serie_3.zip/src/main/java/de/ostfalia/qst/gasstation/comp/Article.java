package de.ostfalia.qst.gasstation.comp;

import java.time.LocalDateTime;

/**
 * This class represents a sellable article. The article inhertis name and price from the Sellable interface.
 * Furthermore the article has an discount object which describes a time span for a valid discount.
 */
public class Article implements Sellable {
    private String name;
    private double price;

    private Discount discount;

    /**
     * Constructor for an article. An article must have a name and a price
     * @param name name of the article
     * @param price price of the article
     */
    public Article(String name, double price) {
        this.name = name;
        this.price = price;
        discount = new Discount(0.00, LocalDateTime.MIN, LocalDateTime.MIN);
    }

    /**
     * Getter for the discount object bound to this article
     * @return discount
     */
    public Discount getDiscount() {
        return this.discount;
    }

    /**
     * Sets the parameter for the discount object of the article. The discount will not be sad
     * if the discount time span is invalid, e.g. when time end < time begin
     * @param price discount price
     * @param begin begin of the discount time span
     * @param end end of the discount time span
     * @return false if the discount is invalid and the discount has not been set,
     * true if the discount has been set
     */
    public boolean setDiscount(double price, LocalDateTime begin, LocalDateTime end) {
        if(begin.isAfter(end)) {
            return false;
        }
        this.discount.price = price;
        this.discount.begin = begin;
        this.discount.end = end;
        return true;
    }
    
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public void setName(String nameArticle) {
        this.name = nameArticle;
    }
    
    @Override
    public double getPrice() {
        return this.price;
    }

    @Override
    public void setPrice(double priceArticle) {
        this.price = priceArticle;
    }
}
