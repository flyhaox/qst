package de.ostfalia.qst.gasstation;

import java.time.LocalDateTime;
import java.util.HashMap;

import de.ostfalia.qst.gasstation.comp.Bill;
import de.ostfalia.qst.gasstation.comp.FillingStation;

/**
 * The main manager class for organizing filling stations. This class contains a hashmap to save
 * filling stations identified by their name. The class contains methods to add and remove filling stations
 * and a method to calculate the revenue of a filling station for a given time range.
 */
public class FillingStationManager {

    private HashMap<String, FillingStation> stations = new HashMap<>();

    /**
     * Default Constructor
     */
    public FillingStationManager() {} //NOSONAR java:S1186 IGNORE Methods should not be empty


    /**
     * Adds a filling station to the manager
     * @param station the station
     * @return true if the station has been added, false if the station has already been added before.
     */
    public boolean add(FillingStation station) {
        if(stations.get(station.getName()) != null) {
            return false;
        }
        stations.put(station.getName(), station);
        return true;
    }

    /**
     * Removes a station from the manager.
     * @param name name as string of the station
     * @return true if the station has been removed, false if the station wasn't included in the manager
     */
    public boolean remove(String name) {
        return stations.remove(name) != null;
    }

    /**
     * Getter for the stations
     * @param name string name of the station
     * @return station with the specified name
     */
    public FillingStation getStation(String name) {
        return this.stations.get(name);
    }

    /**
     * Returns the total revenue of a specified station within a specified time range.
     * The method will look for all bills in the station which has been added within the time range
     * and return the summed revenue of all bills
     * @param station the station
     * @param begin start time of the time range
     * @param end end time of the time range
     * @return sum of all revenues within the time range
     */
    public double getRevenue(FillingStation station, LocalDateTime begin, LocalDateTime end) {
        double revenue = 0;
        for(Bill bill : station.getBills()) {
            if(bill.getTime().isAfter(begin) && bill.getTime().isBefore(end)) {
                revenue += bill.calcTotalSum();
            }
        }

        return revenue;
    }

}
