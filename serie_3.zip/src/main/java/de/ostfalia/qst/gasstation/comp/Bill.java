package de.ostfalia.qst.gasstation.comp;

import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 * This class represents a bill. It includes all items and their amount which have been bought
 * by a customer.
 */
public class
Bill {
    // ohne MwSt: Preis - (Preis * 0.19)

    private LocalDateTime time;
    private boolean isPatron;

    private ArrayList<BillItem> items = new ArrayList<>(); //NOSONAR IGNORE Provide the parametrized type for this generic.

    /**
     * Constructor for a new bill. Takes as argument wether the customer is a patron
     * @param isPatron customer is patron?
     */
    public Bill(boolean isPatron) {
        time = LocalDateTime.now();
        this.isPatron = isPatron;
    }

    /** adds an sellable item and an amount to the bill. Integer Version for articles or fuels
     *
     * @param item the sellable item
     * @param amount amount of item
     */
    public void add(Sellable item, int amount) {
        if(item.getClass() == Article.class) {
            BillItem<Integer> billitem = new BillItemArticle((Article)item, amount);
            this.items.add(billitem);
        } else if(item.getClass() == Fuel.class) {
            BillItem<Double> billitem = new BillItemFuel(item, amount, this.isPatron);
            this.items.add(billitem);
        }
    }

    /**
     * Adds an sellable item and an amount to the bill. Double version for fuel
     * @param item the sellable item
     * @param amount amount of the item
     */
    public void add(Sellable item, double amount) {
        if(item.getClass() == Article.class) {
            System.out.println("Keine Kommazahlen als Artikel möglich alerta alerta exception"); //NOSONAR rule:S106 IGNORE Replace this use of System.out or System.err by a logger.
            return;
        }
        if(item.getClass() == Fuel.class) {
            BillItem<Double> billitem = new BillItemFuel(item, amount, this.isPatron);
            this.items.add(billitem);
        }
    }

    /**
     * Calculates the total sum of the Bill by calling the overridden calcPrice() Functions of the items
     * @return total sum of the bill
     */
    public double calcTotalSum() {
        double totalSum = 0; //java:S1117 Rename "sum" which hides the field declared at line 19.
        for(BillItem item : items) { //NOSONAR IGNORE Provide the parametrized type for this generic.
            totalSum += item.calcPrice();
        }
        return totalSum;
    }

    /**
     * calculates the total sum of the bill without MwSt
      * @return total sum without MwSt
     */
    public double calcTotalWithoutMwSt() {
        double totalSum = this.calcTotalSum();
        totalSum = totalSum - (totalSum * 0.19);
        return totalSum;
    }

    /**
     * gets the time when the bill was created
     * @return the time with date and daytime
     */
    public LocalDateTime getTime() {
        return this.time;
    }

    /**
     * toString() method of the bill. Prints all items on the bill with amount and price, as well as
     * the total price and date of the bill
     * @return Stringified Bill
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for(BillItem row : items) { //NOSONAR IGNORE Provide the parametrized type for this generic.
            sb.append(row.toString()).append("€\n");
        }
        sb.append("\n").
        append("TOTAL: ").append(String.format("%.2f", calcTotalWithoutMwSt())).append("€")
                .append(" | with MwsT: ").append(String.format("%.2f", calcTotalSum())).append("€\n")
                .append("DATUM: ").append(formatTime());

        return sb.toString();
    }

    private String formatTime() {
        StringBuilder sb = new StringBuilder();
        sb.append(time.getDayOfMonth()).append(".").
                append(time.getMonth()).append(".").
                append(time.getYear()).append(" ");

        sb.append(time.getHour()).append(":").
                append(time.getMinute()).append(":").
                append(time.getSecond());

        return sb.toString();
    }
}
