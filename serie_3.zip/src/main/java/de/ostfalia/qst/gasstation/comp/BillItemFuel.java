package de.ostfalia.qst.gasstation.comp;

/**
 * this class represents a single column of the bill for fuels
 * the column includes the type of fuel, the amount as double and the calculated price
 *
 */
public class BillItemFuel extends BillItem<Double> {
    private Sellable fuel;
    private boolean isPatron;

    /** Constructor for a bill column. Takes the type of fuel, the amount of fuel and wether
     * the customer is a patron
     * @param fuel type of fuel
     * @param amount amount of fuel
     * @param isPatron wether the customer is a patron
     */
    public BillItemFuel(Sellable fuel, double amount, boolean isPatron) {
        this.fuel = fuel;
        this.amount = amount;
        this.isPatron = isPatron;
    }

    /**
     * overriden method to calculate the fuel price. Uses the isPatron flag of the class
     * to calculate the patron discount
     * @return price calculated from the fuel price, the amount of fuel and the patron discount
     */
    @Override
    public double calcPrice() {
        double price;
        if(isPatron) {
            price = Math.round(fuel.getPrice() * amount * 100.0) / 100.0 - Math.floor(amount) * 0.01;
        } else
        {
            price = Math.round(fuel.getPrice() * amount * 100.0) / 100.0;
        }
        return price;
    }

    /** outputs the bill column as a string
     *
     * @return formatted string including the fuel, the amount and the price
     */
    @Override
    public String toString() {
        return String.format("%1$-20s",this.fuel.getName()) + "\t" +
                String.format("%1$-7s", this.amount + "L") + " \t" +
                String.format("%.2f", this.calcPrice());
    }
}
