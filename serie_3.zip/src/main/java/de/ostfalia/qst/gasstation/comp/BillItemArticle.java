package de.ostfalia.qst.gasstation.comp;

import java.time.LocalDateTime;


/**
 * this class represents a single column of the bill for articles
 * the column includes the type of article, the amount as integer and the calculated price
 *
 */
public class BillItemArticle extends BillItem<Integer> {
    private Article article;
    private LocalDateTime time;

    /** Constructor for a bill column. Takes the type of article and the amount of the article
     * @param amount type of fuel
     * @param amount amount of fuel
     */
   public BillItemArticle(Article article, int amount) {
       time = LocalDateTime.now();

       this.article = article;
       this.amount = amount;
   }

    /**
     * Calculated the price of the article, including the amount and the possible discount
     * @return the calculated price
     */
    @Override
    public double calcPrice() {
       double price;

       Discount discount = article.getDiscount();
       if(time.isAfter(discount.begin) && time.isBefore(discount.end)) {
           price = article.getDiscount().price * amount;
       }
       else {
           price = article.getPrice() * amount;
       }
       return price;
    }

    /**
     * getter for amount
     * @return amount
     */
    public int getAmount() {
        return amount;
    }

    /**
     * setter for amount
     * @param amount amount
     */
    public void setAmount(int amount) {
        this.amount = amount;
    }

    /**
     * Getter for the time when this article has beend added to the bill
     * @return time
     */
    public LocalDateTime getTime() {
        return time;
    }

    /**
     * Setter for the time when this article has been sold
     * @param time time
     */
    public void setTime(LocalDateTime time) {
        this.time = time;
    }

    /**
     * Returns a string with all information of this buy in a row. Included article name, amount and total price
     * @return formatted string
     */
    @Override
    public String toString() {
       return String.format("%1$-20s",this.article.getName()) + "\t" +
               String.format("%1$-7s", this.amount + "x") + " \t" +
               String.format("%.2f", this.calcPrice());
   }

}

