package de.ostfalia.qst.gasstation.comp;

/**
 * Interface for objects that a filling station can sell.
 * This included fuel and articles. A sellable object has getter/setter for names
 */
public interface Sellable {

    /**
     * Getter for name of the sellable object
     * @return name
     */
    public String getName();

    /**
     * Setter for name of the sellable object
     * @param name new name for the object
     */
    public void setName(String name);

    /**
     * Getter for the price of the sellable object
     * @return
     */
    public double getPrice();

    /**
     * Setter for the price of the sellable obect
     * @param price new price for the object
     */
    public void setPrice(double price);
}
