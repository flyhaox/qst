package de.ostfalia.qst.gasstation.gui;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import de.ostfalia.qst.gasstation.FillingStationManager;
import de.ostfalia.qst.gasstation.comp.Article;
import de.ostfalia.qst.gasstation.comp.Bill;
import de.ostfalia.qst.gasstation.comp.FillingStation;
import de.ostfalia.qst.gasstation.comp.Fuel;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * This class is a JavaFX GUI for managing selling {@link Article}s and {@link Fuel}s from a {@link FillingStation}.
 */
public class SellGUI extends Application {
	
	/**
	 * {@link FillingStation}'s name
	 */
	private static final String STATION_NAME = "Meine Tankstelle";
	
	/**
	 * {@link FillingStationManager} for the managed {@link FillingStation}
	 */
	private final FillingStationManager manager = new FillingStationManager();
	
	/**
	 * Current {@link Bill} where all goods are added. It will be resetted to null, if you show/save bill.
	 */
	private Bill bill = null;
	
	/**
	 * {@link CheckBox} for patron state
	 */
	private CheckBox patronCheckbox;
	/**
	 * {@link ChoiceBox} for {@link Article} list
	 */
	private ChoiceBox<String> listArticle;
	/**
	 * {@link ChoiceBox} for {@link Fuel} list
	 */
	private ChoiceBox<String> listFuel;
	/**
	 * {@link TextField} for {@link Article} amount
	 */
	private TextField articleAmountField;
	/**
	 * {@link TextField} for {@link Fuel} amount
	 */
	private TextField fuelAmountField;
	
	/**
	 * Reference to main window
	 */
	private Stage primaryStage;
	
	/**
	 * Enum for sellable types {@link Article} and {@link Fuel}. It is used for distinguishing the different type while adding an item to bill.
	 */
	private enum SellableType {
		/**
		 * {@link SellableType} for {@link Article}
		 */
		ARTICLE,
		/**
		 * {@link SellableType} for {@link Fuel}
		 */
		FUEL
	}
	
	/**
	 * Creates and shows the main window for selling {@link Article}s and {@link Fuel}s at a {@link FillingStation}
	 * @param primaryStage reference to primary {@link Stage}
	 */
	@Override
	public void start(Stage primaryStage) {
		initFillingStation();
		this.primaryStage = primaryStage;
		
		Text title = new Text("Tankstelle - Verkauf von Waren und Treibstoff");
		title.setStyle("-fx-font: 24 arial;");
		
		Text setPatron = new Text("Stammkundenrabatt aktivieren");
		setPatron.setStyle("-fx-font: 14 arial;");
		
		patronCheckbox = new CheckBox();
		
		Text sellArticle = new Text("Verkauf von Waren");
		sellArticle.setStyle("-fx-font: 14 arial;");
		
		listArticle = new ChoiceBox<String>();
		ObservableList<String> itemsArticle = FXCollections.observableArrayList("Kleines Wasser", "Grosses Wasser", "Belegtes Broetchen", "Kaffee");
		listArticle.setItems(itemsArticle);
		listArticle.setPrefWidth(150);
		
		articleAmountField = new TextField();
		articleAmountField.setPromptText("Anzahl");
		articleAmountField.setPrefColumnCount(10);
		
		Button addArticle = new Button();
		addArticle.setText("Hinzufuegen");
		addArticle.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				addToBill(listArticle.getSelectionModel().getSelectedItem(), articleAmountField.getText(), SellableType.ARTICLE);
			}
		});
		
		Text sellFuel = new Text("Verkauf von Treibstoff");
		sellFuel.setStyle("-fx-font: 14 arial;");
		
		listFuel = new ChoiceBox<String>();
		ObservableList<String> itemsFuel = FXCollections.observableArrayList("Diesel", "E5", "E10");
		listFuel.setItems(itemsFuel);
		listFuel.setPrefWidth(150);
		listFuel.setPrefHeight(27);
		
		fuelAmountField = new TextField();
		fuelAmountField.setPromptText("Liter");
		fuelAmountField.setPrefColumnCount(10);
		
		Button addFuel = new Button();
		addFuel.setText("Hinzufuegen");
		addFuel.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				addToBill(listFuel.getSelectionModel().getSelectedItem(), fuelAmountField.getText(), SellableType.FUEL);
			}
		});
		
		Button showBill = new Button();
		showBill.setText("Kauf abschliessen und Rechnung zeigen");
		showBill.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				showBill();
			}
		});
		
		GridPane grid = new GridPane();
		grid.setHgap(20);
		grid.setVgap(20);
		grid.setPadding(new Insets(20, 20, 20, 20));
		grid.add(setPatron, 0, 0);
		grid.add(patronCheckbox, 1, 0);
		grid.add(sellArticle, 0, 1);
		grid.add(listArticle, 1, 1);
		grid.add(articleAmountField, 2, 1);
		grid.add(addArticle, 3, 1);
		grid.add(sellFuel, 0, 2);
		grid.add(listFuel, 1, 2);
		grid.add(fuelAmountField, 2, 2);
		grid.add(addFuel, 3, 2);
		grid.add(showBill, 0, 3);
		
		BorderPane borderPane = new BorderPane();
		borderPane.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);
		borderPane.setCenter(grid);
		
		Scene scene = new Scene(borderPane, 700, 300);
		primaryStage.setTitle("Tankstelle - Verkauf von Waren und Treibstoff");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	/**
	 * Clears the input forms for adding {@link Article} and {@link Fuel} after adding an item.
	 */
	private void clearForms() {
		listArticle.getSelectionModel().clearSelection();
		listFuel.getSelectionModel().clearSelection();
		articleAmountField.setText("");
		fuelAmountField.setText("");
	}
	
	/**
	 * Opens a new window showing the current {@link Bill}. The bill will be deleted after closing this window.
	 */
	private void showBill() {
		if (bill == null) {
			System.out.println("Es wurde noch keine Kauf begonnen.");
			return;
		}
		
		Text title = new Text("Tankstelle - Rechnung anzeigen");
		title.setStyle("-fx-font: 24 arial;");
		
		TextArea billOutputArea = new TextArea();
		billOutputArea.setEditable(false);
		billOutputArea.setText(bill.toString());
		
		Button saveBill = new Button();
		saveBill.setText("Rechnung als Textdatei speichern");
		saveBill.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				saveBill();
			}
		});
		
		BorderPane borderPane = new BorderPane();
		borderPane.setTop(title);
		BorderPane.setAlignment(title, Pos.CENTER);
		borderPane.setCenter(billOutputArea);
		borderPane.setBottom(saveBill);
		BorderPane.setAlignment(saveBill, Pos.CENTER);
		
		Scene secondScene = new Scene(borderPane, 700, 300);
		
		// New window (Stage)
		Stage newWindow = new Stage();
		newWindow.setTitle("Tankstelle - Rechnung anzeigen");
		newWindow.setScene(secondScene);
		
		// Specifies the modality for new window.
		newWindow.initModality(Modality.WINDOW_MODAL);
		
		// Specifies the owner Window (parent) for new window
		newWindow.initOwner(primaryStage);
		
		newWindow.getScene().getWindow().addEventFilter(WindowEvent.WINDOW_CLOSE_REQUEST, this::closeWindowEvent);
		
		// Set position of second window, related to primary window.
		newWindow.setX(primaryStage.getX() + 200);
		newWindow.setY(primaryStage.getY() + 100);
		
		newWindow.show();
	}
	
	/**
	 * Saves the current {@link Bill} to .txt-file.
	 */
	private void saveBill() {
		if (bill == null) {
			return;
		}
		String[] lines = bill.toString().split("\n");
		String filename = "bill_"+lines[lines.length-1].replace("DATUM: ", "").replace(" ", "_").replace(":", ".");
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(System.getProperty("user.dir")+"/bills/"+filename+".txt"))) {
			for (String line : lines) {
				writer.write(line);
				writer.newLine();
			}
		} catch(IOException ex) {
			ex.printStackTrace();
		}
	}
	
	/**
	 * Deletes (reference to) current {@link Bill} when closing the bill window.
	 * It also resets patron status.
	 * @param event {@link WindowEvent} - not used
	 */
	private void closeWindowEvent(WindowEvent event) {
        bill = null;
        patronCheckbox.setSelected(false);
    }
	
	/**
	 * Add an item to current {@link Bill}. If the bill is null, a new bill will be created with patron status, if patron checkbox is selected.
	 * @param name name of {@link Article} or {@link Fuel}
	 * @param amount {@link String} with amount of item
	 * @param type parameter for distinguishing whether it is an {@link Article} or {@link Fuel}
	 */
	private void addToBill(String name, String amount, SellableType type) {
		if (bill == null) {
			boolean isPatron = patronCheckbox.isSelected();
			bill = new Bill(isPatron);
		}
		
		if (type == SellableType.ARTICLE) {
			int amountInt = 0;
			try {
				amountInt = Integer.parseInt(amount);
			} catch(NumberFormatException ex) {
				
			}
			if (amountInt > 0) {
				bill.add(manager.getStation(STATION_NAME).getGood(name), amountInt);
			}
		} else { // Fuel
			double amountDouble = 0.0;
			try {
				amountDouble = Double.parseDouble(amount);
			} catch(NumberFormatException ex) {
				
			}
			if (amountDouble > 0.0) {
				bill.add(manager.getStation(STATION_NAME).getGood(name), amountDouble);
			}
		}
		clearForms();
	}
	
	/**
	 * Creates a {@link FillingStation} with STATION_NAME and adds it to the {@link FillingStationManager}.
	 */
	private void initFillingStation() {
		FillingStation myFillingStation = new FillingStation(STATION_NAME);
		manager.add(myFillingStation);
	}
	
	/**
	 * Main class starts the program by starting the JavaFX GUI. 
	 * @param args command line parameters - not used
	 */
	public static void main(String[] args) {
		launch(args);
	}
}
