package de.ostfalia.qst.gasstation.comp;

import java.time.LocalDateTime;

/**
 * This class represents a discount which can be bound to an article.
 * The discount contains a discounted price and a time range in which the discount is valid.
 */
public class Discount {
    double price;
    LocalDateTime begin;
    LocalDateTime end;

    /**
     * Constructor for a new discount.
     * @param price discount price
     * @param begin time when the discount starts
     * @param end time when the discount ends
     */
    public Discount(double price, LocalDateTime begin, LocalDateTime end) {
        this.price = price;
        this.begin = begin;
        this.end = end;
    }
}
