package de.ostfalia.qst.gasstation.comp;

/**
 * This class represents a fuel which is sellable by the filling station.
 * It inherits from the Sellable interface and needs to have a name and a price
 */
public class Fuel implements Sellable {

    private String name;
    private double price;

    /**
     * Constructor for a fuel type. A fuel needs a name and a price
     * @param name name of the fuel
     * @param price price per liter
     */
    public Fuel(String name, double price) {
        this.name = name;
        this.price = price;
    }

    /**
     * Getter for name of the fuel
     * @return name
     */
    @Override
    public String getName() { 
        return this.name;
    }

    /**
     * setter for the name of the fuel
     * @param nameFuel new name for the fuel
     */
    @Override
    public void setName(String nameFuel) {
        this.name = nameFuel;
    }

    /**
     * getter for the price of the fuel 
     * @return price per liter
     */
    @Override
    public double getPrice() {
        return this.price;
    }

    /**
     * Setter for the price of the fuel
     * @param priceFuel new price for the fuel per liter
     */
    @Override
    public void setPrice(double priceFuel) {
        this.price = priceFuel;
    }
}
