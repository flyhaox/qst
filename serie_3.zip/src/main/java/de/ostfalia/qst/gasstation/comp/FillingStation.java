package de.ostfalia.qst.gasstation.comp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * This class represents a single Filling Station.
 * It contains the functionality to add Fuels and Articles by their names and prices,
 * to add discounts to inserted articles and to create a bill which include various items
 */
public class FillingStation {

    private String name;

    private HashMap<String, Sellable> goods = new HashMap<>();
    private ArrayList<Bill> bills = new ArrayList<>();

    /**
     * Constructor for a new filling station. Takes the name of the filling station as argument
     * The constructor also inserts the mandatory goods to the Filling Station.
     *
     * @param name name of the Filling Station
     */
    public FillingStation(String name) {
        this.name = name;

        Article smallWater = new Article("Kleines Wasser", 0.99);
        Article bigWater = new Article("Grosses Wasser", 1.99);
        Article bun = new Article("Belegtes Broetchen", 2.00);
        Article coffee = new Article("Kaffee", 1.50);

        Fuel diesel = new Fuel("Diesel", 1.199);
        Fuel e5 = new Fuel("E5", 1.379);
        Fuel e10 = new Fuel("E10", 1.399);

        addGood(diesel);
        addGood(e5);
        addGood(e10);
        addGood(smallWater);
        addGood(bigWater);
        addGood(bun);
        addGood(coffee);
    }

    /**
     * Creator method for a bill. It just calls the constructor of the Bill class and returns a new bill.
     * However, this method is useful, because it logical bounds the creation of bills to a station
     * @param isPatron wether the bill gets the patron discount
     * @return new Bill
     */
    public Bill newBill(boolean isPatron) {
        return new Bill(isPatron);
    }

    /**
     * Saves a bill to the station
     * @param b the bill
     */
    public void saveBill(Bill b) {
        this.bills.add(b);
    }

    /**
     * Adds a sellable item to the statoin
     * @param good the sellable item, e.g. an article or a fuel
     */
    public void addGood(Sellable good) {
        this.goods.put(good.getName(), good);
    }

    /**
     * Getter for all sellable items
     * @param name name of the sellable as String
     * @return Sellable object with the associated name
     */
    public Sellable getGood(String name) {
        return this.goods.get(name);
    }

    /**
     * removes an article from the filling station
     *
     * @param name name of the article
     * @return false if the article was not added to the filling station,
     * true if the remove item was successfully removed
     */
    public boolean removeArticle(String name) {
        if (this.goods.get(name) != null) {
            this.goods.remove(name);
            return true;
        }
        return false;
    }

    public Sellable getSellable(String name) {
        return this.goods.get(name);
    }

    /**
     * Getter for all saved Bills in the station
     * @return list of bills of the station
     */
    public List<Bill> getBills() { //java:S1319 Declarations should use Java collection interfaces such as "List" rather than specific implementation classes such as "LinkedList"
        return this.bills;
    }

    /**
     * Gets the name of the filling station
     * @return name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Setter for name of the filling station
     * @param name new name
     */
    public void setName(String name) {
        this.name = name;
    }
}
