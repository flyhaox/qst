package de.ostfalia.qst.gasstation.comp;

/**
 * Abstract class that represents a single selled item on the bill.
 * Fuel and Articles inherits from this class
 * @param <T> the type for amount. should be integer or double (whole articles or floating point fuels)
 */
public abstract class BillItem<T> {

    private double price; //NOSONAR java:S1068 Unused "private" fields should be removed
    T amount;
    abstract double calcPrice();

    public abstract String toString();

}
