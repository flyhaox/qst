

import de.ostfalia.qst.gasstation.FillingStationManager;
import de.ostfalia.qst.gasstation.comp.Bill;
import de.ostfalia.qst.gasstation.comp.FillingStation;
import de.ostfalia.qst.gasstation.comp.Sellable;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class VerwaltungTest {
    FillingStation fs1 = new FillingStation("fs1");
    FillingStation fs2 = new FillingStation("fs2");
    LocalDateTime time1 = LocalDateTime.of(LocalDate.of(2018, 3, 20), LocalTime.of(12, 0, 0));
    LocalDateTime time2 = LocalDateTime.of(LocalDate.of(2024, 5, 10), LocalTime.of(12, 0, 0));

    /**
     * Hinzufuegen
     */
    @Test
    public void addTest() {
        FillingStationManager fsm = new FillingStationManager();
        fsm.add(fs1);
        fsm.add(fs2);
        Assertions.assertEquals(fsm.getStation("fs1"), fs1);
        Assertions.assertEquals(fsm.getStation("fs2"), fs2);
    }

    /**
     * Loeschen bestehender Tankstellen
     */
    @Test
    public void removeTest1() {
        FillingStationManager fsm = new FillingStationManager();
        fsm.add(fs1);
        fsm.add(fs2);
        fsm.remove("fs1");
        Assertions.assertEquals(fsm.getStation("fs1"), null);
    }

    /**
     * Loeschen nicht bestehender Tankstellen
     */
    @Test
    public void removeTest2() {
        FillingStationManager fsm = new FillingStationManager();
        Assertions.assertEquals(fsm.remove("fs1"), false);
    }

    /**
     * Umsatz bestimmtes Zeitraums
     */
    @Test
    public void RevenueTest1() {
        FillingStationManager fsm = new FillingStationManager();
        fsm.add(fs1);
        Sellable kaffee = fs1.getGood("Kaffee");
        Bill bill = fs1.newBill(false);
        bill.add(kaffee, 1);
        fs1.saveBill(bill);
        Assertions.assertEquals(fsm.getRevenue(fs1, time1, time2), 1.5);
    }

    /**
     * Umsatz bestimmtes Zeitraums ohne Tankstelle
     */
    @Test
    public void RevenueTest2() {
        FillingStationManager fsm = new FillingStationManager();
        Assertions.assertEquals(fsm.getRevenue(fs1, time1, time2), 0);
    }
}
