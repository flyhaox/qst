
import de.ostfalia.qst.gasstation.FillingStationManager;
import de.ostfalia.qst.gasstation.comp.Article;
import de.ostfalia.qst.gasstation.comp.Bill;
import de.ostfalia.qst.gasstation.comp.FillingStation;
import de.ostfalia.qst.gasstation.comp.Sellable;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class GeschaeftsregelnTest {

    LocalDateTime time1 = LocalDateTime.of(LocalDate.of(2018, 3, 20), LocalTime.of(12, 0, 0));
    LocalDateTime time2 = LocalDateTime.of(LocalDate.of(2024, 5, 10), LocalTime.of(12, 0, 0));

    /**
     * Kein Stammkunde, kein Aktionsangebot
     */
    @Test
    public void stammkundenTest1() {
        FillingStationManager fsm = new FillingStationManager();
        FillingStation fs1 = new FillingStation("fs1");
        fsm.add(fs1);
        Sellable diesel = fs1.getGood("Diesel");
        Sellable kaffee = fs1.getGood("Kaffee");
        Bill bill = fs1.newBill(false);
        bill.add(diesel, 50.5);
        bill.add(kaffee, 2);
        Assertions.assertEquals(bill.calcTotalSum(), 63.5495);
    }

    /**
     * Ist Stammkunde, kein Aktionsangebot
     */
    @Test
    public void stammkundenTest2() {
        FillingStationManager fsm = new FillingStationManager();
        FillingStation fs1 = new FillingStation("fs1");
        fsm.add(fs1);
        Sellable diesel = fs1.getGood("Diesel");
        Sellable kaffee = fs1.getGood("Kaffee");
        Bill bill = fs1.newBill(true);
        bill.add(diesel, 50.5);
        bill.add(kaffee, 2);
        Assertions.assertEquals(bill.calcTotalSum(), 63.0445);
    }

    /**
     * kein Stammkunde, ist Aktionsangebot
     */
    @Test
    public void aktionsTest1() {
        FillingStationManager fsm = new FillingStationManager();
        FillingStation fs1 = new FillingStation("fs1");
        fsm.add(fs1);
        Article pepsi = new Article("Pepsi", 1.00);
        pepsi.setDiscount(0.89, time1, time2);
        fs1.addGood(pepsi);
        Sellable diesel = fs1.getGood("Diesel");
        Sellable pepsi1 = fs1.getGood("Pepsi");
        Bill bill = fs1.newBill(false);
        bill.add(diesel, 50.5);
        bill.add(pepsi1, 2);
        Assertions.assertEquals(bill.calcTotalSum(), 62.5495);
    }

    /**
     * Ist Stammkunde, ist Aktionsangebot
     */
    @Test
    public void aktionsTest2() {
        FillingStationManager fsm = new FillingStationManager();
        FillingStation fs1 = new FillingStation("fs1");
        fsm.add(fs1);
        Article pepsi = new Article("Pepsi", 1.00);
        pepsi.setDiscount(0.89, time1, time2);
        fs1.addGood(pepsi);
        Sellable diesel = fs1.getGood("Diesel");
        Sellable pepsi1 = fs1.getGood("Pepsi");
        Bill bill = fs1.newBill(true);
        bill.add(diesel, 50.5);
        bill.add(pepsi1, 2);
        Assertions.assertEquals(bill.calcTotalSum(), 62.0445);
    }

}
