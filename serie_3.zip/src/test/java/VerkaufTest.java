import de.ostfalia.qst.gasstation.comp.Bill;
import de.ostfalia.qst.gasstation.comp.FillingStation;
import de.ostfalia.qst.gasstation.comp.Sellable;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class VerkaufTest {

    @Test
    public void verkaufTest1() {
        FillingStation fs1 = new FillingStation("fs1");
        Sellable diesel = fs1.getGood("Diesel");
        Sellable kleinesWasser = fs1.getGood("Kleines Wasser");
        Bill bill = fs1.newBill(true);
        bill.add(diesel, 10.00);
        bill.add(kleinesWasser, 1);
        System.out.println(bill.toString());
        Assertions.assertEquals(bill.calcTotalSum(), 12.96801);
    }

    @Test
    public void verkaufTest2() {
        FillingStation fs1 = new FillingStation("fs1");
        Sellable diesel = fs1.getGood("Diesel");
        Sellable kleinesWasser = fs1.getGood("Kleines Wasser");
        Sellable grossesWasser = fs1.getGood("Grosses Wasser");
        Bill bill = fs1.newBill(false);
        bill.add(diesel, 20.00);
        bill.add(kleinesWasser, 1);
        bill.add(grossesWasser, 1);
        System.out.println(bill.toString());
        Assertions.assertEquals(bill.calcTotalSum(), 26.96);
    }

    @Test
    public void verkaufTest3() {
        FillingStation fs1 = new FillingStation("fs1");
        Sellable kaffee = fs1.getGood("Kaffee");
        Bill bill = fs1.newBill(true);
        bill.add(kaffee, 1);
        System.out.println(bill.toString());
        Assertions.assertEquals(bill.calcTotalSum(), 1.5);
    }

    @Test
    public void verkaufTest4() {
        FillingStation fs1 = new FillingStation("fs1");
        Sellable diesel = fs1.getGood("Diesel");
        Sellable e10 = fs1.getGood("E10");
        Sellable kaffee = fs1.getGood("Kaffee");
        Sellable belegtesBroetchen = fs1.getGood("Belegtes Broetchen");
        Bill bill = fs1.newBill(true);
        bill.add(diesel, 20.00);
        bill.add(e10, 50.0);
        bill.add(kaffee, 1);
        bill.add(belegtesBroetchen, 1);
        System.out.println(bill.toString());
        Assertions.assertEquals(bill.calcTotalSum(), 96.73);
    }

    @Test
    public void verkaufTest5() {
        FillingStation fs1 = new FillingStation("fs1");
        Sellable e10 = fs1.getGood("E10");
        Bill bill = fs1.newBill(false);
        bill.add(e10, 50.00);
        System.out.println(bill.toString());
        Assertions.assertEquals(bill.calcTotalSum(), 69.95);
    }

}
