import de.ostfalia.qst.gasstation.comp.Bill;
import de.ostfalia.qst.gasstation.comp.FillingStation;
import de.ostfalia.qst.gasstation.comp.Sellable;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class BerechnungTest {

    @Test
    public void treibstoffTest1() {
        FillingStation fs1 = new FillingStation("fs1");
        Sellable diesel = fs1.getGood("Diesel");
        Bill bill = fs1.newBill(false);
        bill.add(diesel, 1.00);
        System.out.println(bill.toString());
        Assertions.assertEquals(bill.calcTotalSum(), 1.199);
    }

    @Test
    public void treibstoffTest2() {
        FillingStation fs1 = new FillingStation("fs1");
        Sellable diesel = fs1.getGood("Diesel");
        Bill bill = fs1.newBill(false);
        bill.add(diesel, 0.99);
        System.out.println(bill.toString());
        Assertions.assertEquals(bill.calcTotalSum(), null);
    }

    @Test
    public void treibstoffTest3() {
        FillingStation fs1 = new FillingStation("fs1");
        Sellable e10 = fs1.getGood("E10");
        Bill bill = fs1.newBill(false);
        bill.add(e10, 1.01);
        System.out.println(bill.toString());
        Assertions.assertEquals(bill.calcTotalSum(), 1.41299);
    }

    @Test
    public void treibstoffTest4() {
        FillingStation fs1 = new FillingStation("fs1");
        Sellable e10 = fs1.getGood("E10");
        Bill bill = fs1.newBill(false);
        bill.add(e10, 150.00);
        System.out.println(bill.toString());
        Assertions.assertEquals(bill.calcTotalSum(), null);
    }

    @Test
    public void treibstoffTest5() {
        FillingStation fs1 = new FillingStation("fs1");
        Sellable e5 = fs1.getGood("E5");
        Bill bill = fs1.newBill(false);
        bill.add(e5, 149.9);
        System.out.println(bill.toString());
        Assertions.assertEquals(bill.calcTotalSum(), 206.7121);
    }

    @Test
    public void treibstoffTest6() {
        FillingStation fs1 = new FillingStation("fs1");
        Sellable e5 = fs1.getGood("E5");
        Bill bill = fs1.newBill(false);
        bill.add(e5, 150.1);
        System.out.println(bill.toString());
        Assertions.assertEquals(bill.calcTotalSum(), null);
    }

    @Test
    public void treibstoffTest7() {
        FillingStation fs1 = new FillingStation("fs1");
        Sellable e6 = fs1.getGood("E6");
        Bill bill = fs1.newBill(false);
        Assertions.assertEquals(e6, null);
    }

}
